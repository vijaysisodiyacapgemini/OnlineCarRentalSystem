package com.cg.onlinecarjdbc.dto;
import java.util.*;
public class BookingDetail {
	private int id;
	private String pickupPoint;
	private String dropPoint;
	private Date pickupDate;
	private Date dropDate;
	 
	private List<Driver> drivers;
	public  int getPId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getPickupPoint() {
		return pickupPoint;
	}

	public void setPickupPoint(String pickupPoint) {
		this.pickupPoint = pickupPoint;
	}

	public String getDropPoint() {
		return dropPoint;
	}

	public void setDropPoint(String dropPoint) {
		this.dropPoint = dropPoint;
	}

	public Date getPickupDate() {
		return pickupDate;
	}

	public void setPickupDate(Date pickupDate) {
		this.pickupDate = pickupDate;
	}

	public Date getDropDate() {
		return dropDate;
	}

	public void setDropDate(Date dropDate) {
		this.dropDate = dropDate;
	}

	public List<Driver> getDrivers() {
		return drivers;
	}

	public void setDrivers(List<Driver> drivers) {
		this.drivers = drivers;
	}
	@Override
	public String toString() {
		return "\n PickupPoint: " + pickupPoint + " DropPoint:" + dropPoint + ",\n PickupDate : " + pickupDate
				+ " DropDate:" + dropDate +  "\n "
				+ drivers;
	}

}

package com.cg.onlinecarjdbc.dto;

import java.math.BigInteger;

public class Car {
	private String carno;
	private String carCategory;
	private float rateHour;
	private BookingDetail bookingdetail;
	public String getCarno() {
		return carno;
	}
	public void setCarno(String carno) {
		this.carno = carno;
	}
	public String getCarCategory() {
		return carCategory;
	}
	public void setCarCategory(String carCategory) {
		this.carCategory = carCategory;
	}
	public float getRateHour() {
		return rateHour;
	}
	public void setRateHour(float rateHour) {
		this.rateHour = rateHour;
	}
	public Car(String carno, String carCategory, float rateHour, BookingDetail bookingdetail) {
		super();
		this.carno = carno;
		this.carCategory = carCategory;
		this.rateHour = rateHour;
		this.bookingdetail = bookingdetail;
	}
	public BookingDetail getBookingdetail() {
		return bookingdetail;
	}
	public void setBookingdetail(BookingDetail bookingdetail) {
		this.bookingdetail = bookingdetail;
	}
	@Override
	public String toString() {
		return "CAR NO:" + carno + "  " + carCategory + "  Rate/Hour:"  + rateHour + " "
				+ bookingdetail;
	}
	 
}

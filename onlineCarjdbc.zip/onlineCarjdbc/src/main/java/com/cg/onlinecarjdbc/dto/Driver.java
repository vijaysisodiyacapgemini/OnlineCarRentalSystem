package com.cg.onlinecarjdbc.dto;

public class Driver {
	@Override
	public String toString() {
		return "Driver   Name : " + name + " MobNumber:"  + mobNumber + " LicenceNumber:"  + LicenceNumber + " \n ";
	}
	private String name;
	private Long mobNumber;
	private String LicenceNumber;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	 
	public Long getMobNumber() {
		return mobNumber;
	}
	public void setMobNumber(Long mobNumber) {
		this.mobNumber = mobNumber;
	}
	public String getLicenceNumber() {
		return LicenceNumber;
	}
	public void setLicenceNumber(String licenceNumber) {
		LicenceNumber = licenceNumber;
	}

}

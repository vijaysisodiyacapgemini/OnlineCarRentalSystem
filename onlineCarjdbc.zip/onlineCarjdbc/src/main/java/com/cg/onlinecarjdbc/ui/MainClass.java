package com.cg.onlinecarjdbc.ui;
 
 
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
 
import java.sql.Timestamp;

import com.cg.onlinecarjdbc.dto.BookingDetail;
import com.cg.onlinecarjdbc.dto.Car;
import com.cg.onlinecarjdbc.dto.Driver;
import com.cg.onlinecarjdbc.service.CarServiceImpl;
import com.cg.onlinecarrental.exception.CarException;
import com.cg.onlinecarrental.util.Dbutil;
public class MainClass {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		CarServiceImpl carservice=new CarServiceImpl();
		Car object2=new Car(null,null,0,null);
	    String carno=null;
	    int choice;
		do {
			System.out.println("Enter choice  \n 1.View Available Cars \n 2.Book Car \n 3.ViewBookingDetail \n 4.Cancel Booking");
			choice=sc.nextInt();
			switch(choice) {
			case 2:
			 BookingDetail bookingdetail=new BookingDetail();
			 List<Driver> driverlist=new ArrayList<Driver>();
			 System.out.println("enter car detail");
		     System.out.println("car no");
		     carno=sc.next();
			 
		     System.out.println("pickup point");
		     String pickupPoint=sc.next();
		     System.out.println("drop point");
	    	 String dropPoint=sc.next();
	    	 System.out.println("enter pickupDate in dd-mm-yy");
	    	 String string1=sc.next();
		     System.out.println("pickup time in HH:MM");
		    String string2=sc.next();
		    System.out.println("enter drop date in dd-mm-yy");
		    String string3=sc.next();
		    System.out.println("drop time in HH:MM");
		    String string4=sc.next();
		    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yy HH:mm");
				Date pickupDate = null;
				Date dropDate=null;
				try {
					pickupDate = dateFormat.parse(string1+" "+string2);
				    dropDate=dateFormat.parse(string3+" "+string4);
				} catch (ParseException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		  
		    String choice1;
		    System.out.println("enters drivers detail");
		  do {
		   Driver driver=new Driver();
		   System.out.println("driver name");
		   String name=sc.next();
		   System.out.println("mobile no");
		   Long mobNumber=sc.nextLong();
		   System.out.println("licence number");
		   String licenceNumber=sc.next();
		   driver.setName(name);
		   driver.setMobNumber(mobNumber);
		   driver.setLicenceNumber(licenceNumber);
		   System.out.println("enter another driver detail yes or no");
		   choice1=sc.next();
		   driverlist.add(driver);
		  }
		  while(choice1.equals("yes"));
		
		  bookingdetail.setPickupPoint(pickupPoint);
		  bookingdetail.setDropPoint(dropPoint);
		  bookingdetail.setPickupDate(pickupDate);
		  bookingdetail.setDropDate(dropDate);
		  bookingdetail.setDrivers(driverlist);
		  object2.setBookingdetail(bookingdetail);
		  object2.setCarno(carno);
				Car car1;
				try {
					car1 = carservice.bookCar(object2);
					 System.out.println("car no  "+car1.getCarno()+ " is booked");
				} catch (CarException e1) {
					// TODO Auto-generated catch block
					e1.getMessage();
				}
		 
		  break;
		 case 3:
		  System.out.println("the details of the booking car");
		  
		  if(carno==null)
			  System.out.println("BOOK THE CAR FIRST");
		  else {
			  try {
		 Car obj=carservice.showBookingDetail(carno);
		 System.out.println(obj);
		 System.out.println("TOTAL AMOUNT :" +carservice.totalamount);
		 }
		 catch(CarException e) {
			 System.out.println(e.getMessage()); } }
		 break;
		 case 1:
				List<Car> carlist;
				try {
					carlist = carservice.viewAvailableCars();
					 for(Car carobj:carlist)
							System.out.println("CAR NUMBER: "+carobj.getCarno()+ "  "+carobj.getCarCategory()+"  "+"RATE/HOUR: "+carobj.getRateHour());
				} catch (CarException e) {
					// TODO Auto-generated catch block
					e.getMessage();
				}
				  
				    break;	
         case 4:
				try {
					carservice.cancelBooking(carno);
					 System.out.println("you have canceled booking  of car no : "+ carno);
				} catch (CarException e) {
					// TODO Auto-generated catch block
					e.getMessage();
					
				}
			 
			  break; }
		}
		while(choice!=5);
        }}

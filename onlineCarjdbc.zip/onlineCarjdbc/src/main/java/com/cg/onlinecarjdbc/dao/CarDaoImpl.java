package com.cg.onlinecarjdbc.dao;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.cg.onlinecarjdbc.dto.*;
import com.cg.onlinecarjdbc.dto.Driver;
import com.cg.onlinecarjdbc.query.CarQuery;

import java.util.*;
import java.util.Date;

import com.cg.onlinecarrental.exception.CarException;
import com.cg.onlinecarrental.util.Dbutil;
 
public class CarDaoImpl implements CarDao {
	
	
	
	public Car save(Car car) throws CarException {
		
		try {
			Connection conn=Dbutil.getConnection();
			
			PreparedStatement stmtt=conn.prepareStatement(CarQuery.queryone);
			stmtt.setString(1, car.getCarno());
			ResultSet resultset=stmtt.executeQuery();
			if(resultset.next())
			{
				throw new CarException("THIS CAR IS ALREADY BOOK EITHER CANCEL THE BOOKING \n OR BOOK ANOTHER CAR");
				
			}
		} 
		
		catch (SQLException e1) {
			// TODO Auto-generated catch block
			 
			
		}
		
		  try {
			 
			
			Connection con=Dbutil.getConnection();
			
			PreparedStatement stmt=con.prepareStatement(CarQuery.query);
			
			BookingDetail obj=car.getBookingdetail();
			 Timestamp ts1=new Timestamp(obj.getPickupDate().getTime());
			   Timestamp ts2=new Timestamp(obj.getDropDate().getTime());
			stmt.setString(1, obj.getPickupPoint());
			stmt.setString(2, obj.getDropPoint());
			stmt.setTimestamp(3, ts1);
			stmt.setTimestamp(4, ts2);
			stmt.setString(5, car.getCarno());
			stmt.executeUpdate();
			
			
			PreparedStatement stmt2=con.prepareStatement(CarQuery.query2);
			stmt2.setString(1, car.getCarno());
			ResultSet rs=stmt2.executeQuery();
			rs.next();
			int id=rs.getInt(1);
			List<Driver> mylist =obj.getDrivers();
			
			
			
			for(Driver driver:mylist)
			{
				
				PreparedStatement stmt1=con.prepareStatement(CarQuery.query1);
				stmt1.setString(1, driver.getName());
				stmt1.setLong(2, driver.getMobNumber());
				stmt1.setString(3,driver.getLicenceNumber() );
				stmt1.setInt(4, id);
			
			 
				stmt1.executeUpdate();
				
			}
			
		 
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return car;
	}
		 
		
		 

	public Car findCarByNo(String carno) throws CarException {
		
		// TODO Auto-generated method stub
		BookingDetail bookingdetail=new BookingDetail();
		
		try {
	    Connection con=Dbutil.getConnection();
		 
		PreparedStatement stmt2=con.prepareStatement(CarQuery.queryone);
		stmt2.setString(1, carno);
		ResultSet rs=stmt2.executeQuery();
		rs.next();
		int id=rs.getInt(1);
		String pickuppoint=rs.getString(2);
		String droppoint=rs.getString(3);
		String string=rs.getString(4);
		String string1=rs.getString(5); 
		 
	 
		Date pickupDate=null;
		Date dropDate=null;
		System.out.println("Date Time"+string);
		
		try {
			pickupDate=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(string);
			dropDate=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(string1);
			System.out.println("Date after "+pickupDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		 
	   
	  
		 
		String carno1=rs.getString(6);
		List<Driver> driverlist=new ArrayList<Driver>();
		 
		
		 
		PreparedStatement stmt3=con.prepareStatement(CarQuery.query3);
		stmt3.setInt(1, id);
		ResultSet rs3=stmt3.executeQuery();
		while(rs3.next())
		{
			String name=rs3.getString(1);
			Long mobno=rs3.getLong(2);
			String licence=rs3.getString(3);
	
			int book=rs3.getInt(4);
			Driver driver=new Driver();
			System.out.println(name);
			driver.setName(name);
			driver.setMobNumber(mobno);
			driver.setLicenceNumber(licence);
			System.out.println(driver);
			driverlist.add(driver);
	    }
		bookingdetail.setPickupPoint(pickuppoint);
		bookingdetail.setDropPoint(droppoint);
		bookingdetail.setPickupDate(pickupDate);
		bookingdetail.setDropDate(dropDate);
		bookingdetail.setDrivers(driverlist);
		
		
		PreparedStatement stmt4=con.prepareStatement(CarQuery.query4);
		stmt4.setString(1, carno);
		ResultSet rs4=stmt4.executeQuery();
		rs4.next();
		Car car=new Car(rs4.getString(1),rs4.getString(2),rs4.getFloat(3),bookingdetail);
		return car;
		
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	 return null;
	}

	public List<Car> geCars() throws CarException {
		// TODO Auto-generated method stub
		List<Car> carlist=new ArrayList<Car>();
		 
		try {
			Connection con=Dbutil.getConnection();
			
			PreparedStatement stmt=con.prepareStatement(CarQuery.fetchcar);
			ResultSet rs=stmt.executeQuery();
			while(rs.next())
			{
				Car car=new Car(rs.getString(1),rs.getString(2),rs.getFloat(3),null);
				
				carlist.add(car);
				
			}
			return carlist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 return null;
	}
     
  public boolean delete(String carno) throws CarException
  {
	 
		try {
			Connection con=Dbutil.getConnection();
			PreparedStatement stmt=con.prepareStatement(CarQuery.deletequery);
			stmt.setString(1, carno);
			stmt.executeUpdate();
			return true;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	  return false;
  }
		  
	 
	 
		// TODO Auto-generated constructor stub

   
  

}

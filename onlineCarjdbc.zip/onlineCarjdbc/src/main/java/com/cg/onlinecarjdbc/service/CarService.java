package com.cg.onlinecarjdbc.service;
import java.util.List;

import com.cg.onlinecarjdbc.dto.Car;
import com.cg.onlinecarrental.exception.CarException; 
public interface CarService {
    public List<Car> viewAvailableCars() throws CarException;
    public Car bookCar(Car car) throws CarException; 
    public Car showBookingDetail(String carno) throws CarException;
    public boolean cancelBooking(String carno) throws CarException;
}

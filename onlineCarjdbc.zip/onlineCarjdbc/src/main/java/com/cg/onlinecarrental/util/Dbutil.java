package com.cg.onlinecarrental.util;
import com.cg.onlinecarjdbc.dto.*;
import com.cg.onlinecarrental.exception.CarException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.*;
import java.util.Map;
import java.util.TreeMap;

 
public class Dbutil {
	static Connection con;
	public static Connection getConnection() throws CarException 
	{
		
		try {
		InputStream it=null;
		String driver=null,url=null,uname=null,password=null;
		
		  it=new FileInputStream("src/main/resources/jdbc.properties");
		  Properties prop=new Properties();
		  prop.load(it);
		  driver=prop.getProperty("jdbc.driver");
		  url=prop.getProperty("jdbc.url");
		  uname=prop.getProperty("jdbc.uname");
		  password=prop.getProperty("jdbc.password");
		  Class.forName(driver);
		  
			con=DriverManager.getConnection(url,uname,password);
		 
			// TODO Auto-generated catch block
	 
	 
		  return con;
		}
		catch(SQLException e)
		{
			 throw new CarException("connection is not esatablished");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			 throw new CarException("file is not found");
		 
		} catch (IOException e) {
			// TODO Auto-generated catch block
			 throw new CarException("connection is not esatablished");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			 throw new CarException("class is not found");
			 
		}
		
		  
		
	}
}